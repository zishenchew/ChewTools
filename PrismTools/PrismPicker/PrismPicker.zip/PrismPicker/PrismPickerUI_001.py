# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:/1 - Work/5. Python/PrismTools/PrismPicker/PrismPickerUI_001.ui'
#
# Created: Mon Feb 12 13:41:21 2018
#      by: pyside-uic 0.2.14 running on PySide 1.2.0
#
# WARNING! All changes made in this file will be lost!

from PySide import QtCore, QtGui

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(700, 700)
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.headButton = QtGui.QToolButton(self.centralwidget)
        self.headButton.setGeometry(QtCore.QRect(360, 40, 71, 71))
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/UIBG/UI_button.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.headButton.setIcon(icon)
        self.headButton.setIconSize(QtCore.QSize(100, 100))
        self.headButton.setObjectName("headButton")
        self.neckButton = QtGui.QToolButton(self.centralwidget)
        self.neckButton.setGeometry(QtCore.QRect(380, 110, 30, 30))
        self.neckButton.setText("")
        self.neckButton.setIcon(icon)
        self.neckButton.setIconSize(QtCore.QSize(100, 100))
        self.neckButton.setObjectName("neckButton")
        self.chestButton3 = QtGui.QToolButton(self.centralwidget)
        self.chestButton3.setGeometry(QtCore.QRect(360, 140, 70, 70))
        self.chestButton3.setText("")
        self.chestButton3.setIcon(icon)
        self.chestButton3.setIconSize(QtCore.QSize(100, 100))
        self.chestButton3.setObjectName("chestButton3")
        self.chestButton2 = QtGui.QToolButton(self.centralwidget)
        self.chestButton2.setGeometry(QtCore.QRect(370, 220, 50, 50))
        self.chestButton2.setText("")
        self.chestButton2.setIcon(icon)
        self.chestButton2.setIconSize(QtCore.QSize(100, 100))
        self.chestButton2.setObjectName("chestButton2")
        self.chestButton1 = QtGui.QToolButton(self.centralwidget)
        self.chestButton1.setGeometry(QtCore.QRect(370, 280, 50, 50))
        self.chestButton1.setText("")
        self.chestButton1.setIcon(icon)
        self.chestButton1.setIconSize(QtCore.QSize(100, 100))
        self.chestButton1.setObjectName("chestButton1")
        self.fkUpperArm = QtGui.QLabel(self.centralwidget)
        self.fkUpperArm.setGeometry(QtCore.QRect(250, 150, 101, 31))
        self.fkUpperArm.setObjectName("fkUpperArm")
        self.fkLowerArm = QtGui.QLabel(self.centralwidget)
        self.fkLowerArm.setGeometry(QtCore.QRect(130, 150, 101, 31))
        self.fkLowerArm.setObjectName("fkLowerArm")
        self.ik_Right = QtGui.QLabel(self.centralwidget)
        self.ik_Right.setGeometry(QtCore.QRect(70, 140, 51, 51))
        self.ik_Right.setObjectName("ik_Right")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtGui.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QtGui.QApplication.translate("MainWindow", "MainWindow", None, QtGui.QApplication.UnicodeUTF8))
        self.headButton.setToolTip(QtGui.QApplication.translate("MainWindow", "<html><head/><body><p><img src=\":/UIBG/UI_button.png\"/><img src=\":/UIBG/UI_button.png\"/></p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.headButton.setText(QtGui.QApplication.translate("MainWindow", "aerasd", None, QtGui.QApplication.UnicodeUTF8))
        self.neckButton.setToolTip(QtGui.QApplication.translate("MainWindow", "<html><head/><body><p><img src=\":/UIBG/UI_button.png\"/><img src=\":/UIBG/UI_button.png\"/></p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.chestButton3.setToolTip(QtGui.QApplication.translate("MainWindow", "<html><head/><body><p><img src=\":/UIBG/UI_button.png\"/><img src=\":/UIBG/UI_button.png\"/></p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.chestButton2.setToolTip(QtGui.QApplication.translate("MainWindow", "<html><head/><body><p><img src=\":/UIBG/UI_button.png\"/><img src=\":/UIBG/UI_button.png\"/></p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.chestButton1.setToolTip(QtGui.QApplication.translate("MainWindow", "<html><head/><body><p><img src=\":/UIBG/UI_button.png\"/><img src=\":/UIBG/UI_button.png\"/></p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.fkUpperArm.setText(QtGui.QApplication.translate("MainWindow", "<html><head/><body><p><img src=\":/UIBG/UI_button.png\"/></p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.fkLowerArm.setText(QtGui.QApplication.translate("MainWindow", "<html><head/><body><p><img src=\":/UIBG/UI_button.png\"/></p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.ik_Right.setText(QtGui.QApplication.translate("MainWindow", "<html><head/><body><p><img src=\":/UIBG/UI_button.png\"/></p></body></html>", None, QtGui.QApplication.UnicodeUTF8))

import PickerUI_rc
